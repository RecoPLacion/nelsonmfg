ace.define("ace/snippets/c9search",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "c9search";

});                (function() {
                    ace.require(["ace/snippets/c9search"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            